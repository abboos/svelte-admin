module.exports = [
    {
        name: '@storybook/preset-scss',
        options: {
            cssLoaderOptions: {
                sourceMap: true,
            },
        },
    },
]
