<script>
    import Button from './Button.svelte'
    import Outline from './Outline.svelte'
</script>

<!-- We can add mutiple variations of components as a single component in storybook  -->

<h3>Colored button!</h3>
<Button />

<h3>Simple button!</h3>
<Outline />
