<script>
import SimpleCheckBox from './SimpleCheckBox.svelte'
</script>

<SimpleCheckBox></SimpleCheckBox>