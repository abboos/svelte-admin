<script>
    import { TextField } from 'svelte-admin'
</script>

<TextField label="Number" type="number" />
<TextField label="Password" type="password" />
<TextField label="File" type="file" />
