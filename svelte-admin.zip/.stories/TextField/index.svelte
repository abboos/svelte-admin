<script>
    import Simple from './Simple.svelte'
    import Rtl from './Rtl.svelte'
    import Binding from './Binding.svelte'
    import WithIcon from './WithIcon.svelte'
    import Textarea from './Textarea.svelte'
    import Types from './Types.svelte'
</script>

<!-- We can add mutiple variations of components as a single component in storybook  -->

<h3>Simple</h3>
<Simple />

<h3>RTL</h3>
<Rtl />

<h3>Binding</h3>
<Binding />

<h3>With icon</h3>
<WithIcon />

<h3>Text area</h3>
<Textarea />

<h3>Different Types</h3>
<Types />
