<script>
    import { TextField } from 'svelte-admin'
</script>

<TextField label="Simple" />
<TextField placeholder="Placeholder" />
<TextField label="Disabled" disabled />
<TextField label="Invalid" invalid />
