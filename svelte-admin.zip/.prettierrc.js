module.exports = {
    trailingComma: 'es5',
    tabWidth: 4,
    semi: false,
    singleQuote: true,
    printWidth: 80,
    plugins: ['prettier-plugin-svelte'],
}
